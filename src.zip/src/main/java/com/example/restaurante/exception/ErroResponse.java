package com.example.restaurante.exception;

import java.time.LocalDateTime;
import java.util.List;

public record ErroResponse(
        LocalDateTime timestamp,
        Integer statusCode,
        String erro,
        List<String> mensagens
) {
}
